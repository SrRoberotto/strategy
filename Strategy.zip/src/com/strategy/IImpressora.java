package com.strategy;

public interface IImpressora {
    void imprimir(String nota);
}
